require("dotenv").config();
// Global configurations object contains Application Level variables such as:
// client secrets, passwords, connection strings, and misc flags
const configurations = {
  ConnectionStrings: {
    MongoDB: "mongodb+srv://Aayush:Aayush123@cluster0.dt5pv.mongodb.net/",
  },
  Authentication: {
    GitHub: {
      ClientId: "Iv23liIM91RKKPBOwY19",
      ClientSecret: "9f949610b121617f6d07eaf62b56132e3ebd515f",
      CallbackUrl: "http://localhost:3000/github/callback",
    },
  },
};
module.exports = configurations;
