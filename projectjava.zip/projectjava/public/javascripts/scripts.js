// collection of frontend JS functions
// Delete Confirmation
function confirmDeletion() {
    return confirm("Are you sure?");
}