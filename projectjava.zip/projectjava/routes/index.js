const express = require("express");
const router = express.Router();
const User = require("../models/user");
const passport = require("passport");

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("index", { title: "Express", user: req.user });
});

// GET /login
router.get("/login", (req, res, next) => {
  // Obtain session messages if any
  let messages = req.session.messages || [];
  // Clear messages
  req.session.messages = [];
  // Pass messages to view
  res.render("login", { title: "Login", messages: messages, user: req.user });
});

// POST /login
// Syntax will be a bit different since login will be handled by passport
router.post(
  "/login",
  passport.authenticate("local", {
    successRedirect: "/projects",  // Make sure this is the correct path
    failureRedirect: "/login",
    failureMessage: "Invalid credentials",
  })
);

// GET /register
router.get("/register", (req, res, next) => {
  res.render("register", { title: "Create a New Account", user: req.user });
});

// POST /register
router.post("/register", (req, res, next) => {
  // Ensure we don't have empty fields
  if (!req.body.username || !req.body.password) {
    return res.redirect("/register");
  }

  // Create a new user based on the information from the page
  User.register(
    new User({
      username: req.body.username,
    }),
    req.body.password,
    (err, newUser) => {
      if (err) {
        console.log(err);
        // Handle registration errors
        req.session.messages = ['Error occurred while creating an account. Please try again.'];
        return res.redirect("/register");
      } else {
        // Log user in and redirect
        req.login(newUser, (err) => {
          if (err) {
            req.session.messages = ['Error logging in after registration.'];
            return res.redirect("/login");
          }
          res.redirect("/projects"); // Corrected to /projects
        });
      }
    }
  );
});

// GET /logout
router.get("/logout", (req, res, next) => {
  req.logout((err) => {
    res.redirect("/login");
  });
});

// GET /github
// Triggered when the user clicks on the "Login with GitHub" button on the login page
router.get(
  "/github",
  passport.authenticate("github", { scope: ["user:email"] })
);

// GET /github/callback
router.get(
  "/github/callback", // Path
  passport.authenticate("github", { failureRedirect: "/login" }), // GitHub middleware
  (req, res, next) => {
    res.redirect("/projects"); // Redirect to projects after successful login
  } // Custom middleware (success)
);

module.exports = router;
