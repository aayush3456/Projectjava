const express = require("express");
const router = express.Router();
const Project = require("../models/project"); // Changed to "product tracker"
const Course = require("../models/course");
const AuthenticationMiddleware = require("../extensions/authentication");

// GET /product-trackers/
router.get("/", async (req, res, next) => {
  let projects = await Project.find().sort([["orderDate", "descending"]]); // Changed dueDate to orderDate
  res.render("project/index", {  // Changed from "projects" to "product-trackers"
    title: "Product Tracker",
    dataset: projects,
    user: req.user,
  });
});

// GET /product-trackers/add
router.get("/add", AuthenticationMiddleware, async (req, res, next) => {
  let courseList = await Course.find().sort([["name", "ascending"]]);
  res.render("project/add", {  // Changed from "projects" to "product-trackers"
    title: "Add a new Product",
    courses: courseList,
    user: req.user,
  });
});

// POST /product-trackers/add
router.post("/add", AuthenticationMiddleware, async (req, res, next) => {
  let newProject = new Project({
    name: req.body.name,
    orderDate: req.body.orderDate, // Changed dueDate to orderDate
    product: req.body.product, // Changed course to product
  });
  await newProject.save();
  res.redirect("/projects");  // Changed from "/projects" to "/product-trackers"
});

// GET /product-trackers/delete/_id
router.get("/delete/:_id", AuthenticationMiddleware, async (req, res, next) => {
  let projectId = req.params._id;
  await Project.findByIdAndRemove({ _id: projectId });
  res.redirect("/projects");  // Changed from "/projects" to "/product-trackers"
});

// GET /product-trackers/edit/_id
router.get("/edit/:_id", AuthenticationMiddleware, async (req, res, next) => {
  let projectId = req.params._id;
  let projectData = await Project.findById(projectId);
  let courseList = await Course.find().sort([["name", "ascending"]]);
  res.render("project/edit", {  // Changed from "projects" to "product-trackers"
    title: "Edit Product Info",  // Changed from "Edit Project Info"
    project: projectData,
    courses: courseList,
    user: req.user,
  });
});

// POST /product-trackers/edit/_id
router.post("/edit/:_id", AuthenticationMiddleware, async (req, res, next) => {
  let projectId = req.params._id;
  await Project.findByIdAndUpdate(
    { _id: projectId }, // filter to find the project to update
    {
      name: req.body.name,
      orderDate: req.body.orderDate, // Changed dueDate to orderDate
      product: req.body.product, // Changed course to product
      status: req.body.status,
    }
  );
  res.redirect("/projects");  // Changed from "/projects" to "/product-trackers"
});

module.exports = router;
