const express = require("express");
const router = express.Router();
const Course = require("../models/course"); // Original import
const AuthenticationMiddleware = require("../extensions/authentication");

// GET /courses/ - List all courses
router.get("/", async (req, res, next) => {
  try {
    let courses = await Course.find().sort([["name", "ascending"]]); // Fetch courses
    res.render("course/index", { 
      title: "Product List", 
      dataset: courses, 
      user: req.user 
    }); // Render the courses index view
  } catch (error) {
    next(error); // Pass errors to the error handler middleware
  }
});

// GET /courses/add - Show the form to add a new course
router.get("/add", AuthenticationMiddleware, (req, res, next) => {
  res.render("course/add", { 
    title: "Add a New Course", 
    user: req.user 
  }); // Render the add course view
});

// POST /courses/add - Handle the form submission to create a new course
router.post("/add", AuthenticationMiddleware, async (req, res, next) => {
  try {
    const { name, code } = req.body;

    // Validate course data (ensure name and code are provided)
    if (!name || !code) {
      return res.status(400).render("course/add", {
        title: "Add a New Course", 
        error: "Course name and code are required.",
        user: req.user 
      });
    }

    // Create a new course object and save it
    let newCourse = new Course({ 
      name, 
      code 
    });

    await newCourse.save();
    res.redirect("/courses"); // Redirect to the courses list page
  } catch (error) {
    next(error); // Pass errors to the error handler middleware
  }
});

module.exports = router;
